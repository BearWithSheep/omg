package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

  private TextView tvGreeting;
  private ImageView ivMeal;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    tvGreeting = findViewById(R.id.tv_greeeting);
    ivMeal = findViewById(R.id.iv_meal);


    try {
      FileInputStream  imageInputStream = openFileInput("hamburger.jpg");
      Bitmap bitmap = BitmapFactory.decodeStream(imageInputStream);
      imageInputStream.close();
      ivMeal.setImageBitmap(bitmap);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (IOException e){
      throw new RuntimeException(e);
    }

    File prjDir = this.getFilesDir();
    File  inputFile = new File(prjDir, "Hello.txt");

    try {
      FileInputStream fis = new FileInputStream(inputFile);
      InputStreamReader isr = new InputStreamReader(fis);
      BufferedReader br = new BufferedReader(isr);

      StringBuilder sb = new StringBuilder ();
      String line = "";
      while((line = br.readLine()) != null){
        sb.append(line);
      }

      fis.close();
      isr.close();
      br.close();

      String output = sb.toString();
      tvGreeting.setText(output);

    } catch (FileNotFoundException e){
      throw new RuntimeException(e);
    } catch (IOException e){
      throw  new RuntimeException(e);
    }

    /*try {
      FileOutputStream fos = new FileOutputStream(outputFile);
      String outString = "Hello world!!\nHello FCU!!\n";
      byte[] bytes = outString.getBytes();
      fos.write(bytes);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }*/

  }
}